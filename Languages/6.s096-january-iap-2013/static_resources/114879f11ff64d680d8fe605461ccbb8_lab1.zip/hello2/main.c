#include "hello.h"

int main() {
	say_hello();
	return 0;
}
