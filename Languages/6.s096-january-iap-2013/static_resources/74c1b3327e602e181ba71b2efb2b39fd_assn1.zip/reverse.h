#ifndef _REVERSE_H
#define _REVERSE_H

void reverse(char *str, int len);

#endif
