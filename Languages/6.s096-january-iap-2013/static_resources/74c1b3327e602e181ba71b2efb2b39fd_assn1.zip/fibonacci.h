#ifndef _FIBONACCI_H
#define _FIBONACCI_H

int fib(int n);
void print_fib(int n);

#endif
